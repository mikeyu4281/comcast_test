package com.example.demo;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.ws.rs.Consumes;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.joda.time.DateTime;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.RequestCommand;

@RestController
public class HomeController {

	
	
	public HomeController() {
		
		
		
	}

	
	@RequestMapping(value = "/command", method=RequestMethod.POST)
	 @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
	public JSONObject getCommands(@RequestBody JSONObject command) {
		System.out.println("Employees getter");
		
	
		System.out.println(command.toString());
		
		System.out.println(command.keySet());
		
		Set<Object> keys = command.keySet();
		
		List<String> speakerList = new ArrayList<String>();
		LinkedHashMap<String, String> commandObject = new LinkedHashMap<String, String>();
		
		LinkedHashMap<String,String> items = new LinkedHashMap<String,String>();
		
		JSONArray testArray = new JSONArray();
		for(Object item: keys) {
			System.out.println("item----"+command.get(item));
			speakerList = (List<String>) command.get(item);
			this.parseEntry(speakerList);
		}
		
		System.out.println(speakerList.toString());
		LinkedHashMap<String,String> entryItem = new LinkedHashMap<String,String>();
		
		
		
		long startTime = System.currentTimeMillis();
		DateTime timestamp = new DateTime();
		
	
		//state
		//speaker
		//command
		JSONObject jsonObject = new JSONObject();
		JSONArray topCommandsNationally = new JSONArray();
	

		JSONObject response = new JSONObject();
		JSONObject data = new JSONObject();
		for(Object state: keys) {
			response.put(state, this.getJsonRequest((List<String>)command.get(state), startTime));
		}
	
		
		
		response.put("topCommandsNationally", getMaxCommands(keys));
		
		return response;
	}
	
	private JSONArray getMaxCommands(Object keys) {
		JSONArray resultArray = new JSONArray();
		
		
		
		return resultArray;
	}
	
	private JSONObject getJsonRequest(List<String> entry, long startTime) {
		
		JSONObject item = new JSONObject();
		
		item.put("mostFrequentCommand", parseEntry(entry));
		item.put("startProcessTime", startTime);
		long endTime = System.currentTimeMillis();
		item.put("stopProcessTime", endTime);
		
		return item;
	}
	
	private String findMostFrequentCommand(List<String> item) {
		
		String result  = "";
		
		
		return result;
	}
	
	private Map<String,Integer> parseEntry(List<String> entry) {
		
		Map<String,Integer> resultMap = new TreeMap<String,Integer>();
	
		LinkedHashMap<String, String> commandObject = new LinkedHashMap<String, String>();
		
		for(Object item : entry) {
			System.out.println("Parse----------"+item);
			commandObject = (LinkedHashMap<String,String>)item;

			System.out.println(commandObject.get("command"));
		
			if(!resultMap.containsKey(commandObject.get("command"))){
				resultMap.put(commandObject.get("command"), 1);
			}else if(resultMap.containsKey(commandObject.get("command"))){
				
				
				int count = resultMap.get(commandObject.get("command"));
				count++;
				resultMap.put(commandObject.get("command"), count);
				System.out.println(commandObject.get("command") + " count:  " + count);
			}
		}
	
		return resultMap;
	}


}
