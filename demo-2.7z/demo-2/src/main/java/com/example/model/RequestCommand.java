package com.example.model;

import org.joda.time.DateTime;

public class RequestCommand {

	
	private String speaker;
	private String command;

	
	public String getSpeaker() {
		return speaker;
	}
	public void setSpeaker(String speaker) {
		this.speaker = speaker;
	}
	public String getCommand() {
		return command;
	}
	public void setCommand(String command) {
		this.command = command;
	}
	
	
}
