package com.example.services;

public interface IDaoService {

}
