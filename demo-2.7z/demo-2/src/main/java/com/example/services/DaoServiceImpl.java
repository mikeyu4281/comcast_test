package com.example.services;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DaoServiceImpl implements IDaoService {

	private Connection con;

	public DaoServiceImpl() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sonoo", "root", "root");
			// here sonoo is database name, root is username and password
			
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void save(String state, String command) throws SQLException {
		Statement stmt = con.createStatement();

		String sql = "INSERT INTO Command " + "VALUES (state, command)";
		stmt.executeUpdate(sql);
	
	

	}
	
	public String getFrequentCommand(String id) throws SQLException {
		
		
		String result = "";
		
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("select * from emp");
		while (rs.next())
			System.out.println(rs.getInt(1) + "  " + rs.getString(2) + "  " + rs.getString(3));
		con.close();
		
		
		return result;
	}
}
