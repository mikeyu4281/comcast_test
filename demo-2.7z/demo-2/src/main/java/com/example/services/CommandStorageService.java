package com.example.services;

import com.example.model.RequestCommand;

public class CommandStorageService implements ICommandService{

	public void save(RequestCommand command) {
		
	}
}
