package com.example.services;

import com.example.model.RequestCommand;

public interface ICommandService {
	public void save(RequestCommand command);
}
